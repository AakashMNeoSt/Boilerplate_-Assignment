﻿namespace Assignment_5.Models.Pizza
{
    public class CreatePizzaDto
    {
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string? Description { get; set; }
    }
}
