﻿namespace Assignment_5.Model.Users
{
    public class Logindto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
