﻿namespace Assignment_5.Model.Users
{
    public class AuthresponseDto
    {
        public string UserId { get; set; }
        public string Token { get; set; }

        public string RefreshToken { get; set; }
    }
}
