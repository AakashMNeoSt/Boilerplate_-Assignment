﻿using Assignment_5.Model.Users;
using Microsoft.AspNetCore.Identity;

namespace Assignment_5.Repository
{
    public interface IAuthManager
    {
       Task<IEnumerable<IdentityError>> RegisterUser(ApiUserDto userDto);
        Task<AuthresponseDto> Login(Logindto logindto);

        Task<string> CraeteRefreshToken();
        Task<AuthresponseDto> VerifyRefreshToken(AuthresponseDto request);
    }
}
