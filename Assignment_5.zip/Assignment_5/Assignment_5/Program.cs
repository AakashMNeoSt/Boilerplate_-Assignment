using Microsoft.AspNetCore.Identity;
using PizzaWebProjectAPI.Configuration;
using Assignment_5.Context.Configurations;
using Assignment_5.Context;
using Microsoft.EntityFrameworkCore;
using Assignment_5.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace Assignment_5
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            string Conn = builder.Configuration.GetConnectionString("localString");
            builder.Services.AddDbContext<PizzaDbContext>(option => option.UseSqlServer(Conn));

            builder.Services.AddScoped<IPizzaRepository, PizzaRepository>();
            builder.Services.AddAutoMapper(typeof(MapperConfig));
            builder.Services.AddIdentityCore<APIUser>()
                            .AddRoles<IdentityRole>()
                            .AddTokenProvider<DataProtectorTokenProvider<APIUser>>("PizzaApi")
                            .AddEntityFrameworkStores<PizzaDbContext>()
                            .AddDefaultTokenProviders();
            builder.Services.AddScoped<IAuthManager, AuthManger>();
            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    ValidateLifetime = true,

                    ValidIssuer = builder.Configuration["JwtSetting:Issuer"],
                    ValidAudience = builder.Configuration["JwtSetting:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JwtSetting:Key"]))
                };
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}