﻿using AutoMapper;
using Assignment_5.Context;
using Assignment_5.Context.Configurations;
using Assignment_5.Model.Users;
using Assignment_5.Models.Pizza;

namespace PizzaWebProjectAPI.Configuration
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<Pizza,CreatePizzaDto>().ReverseMap();
            CreateMap<Pizza,GetAllPizzaDto>().ReverseMap();
            CreateMap<Pizza,GetAPizzaDto>().ReverseMap();
            CreateMap<ApiUserDto, APIUser>().ReverseMap();
        }
    }
}
