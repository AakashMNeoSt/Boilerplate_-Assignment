﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Assignment_5.Context.Configurations;

using System.Diagnostics.Metrics;

namespace Assignment_5.Context
{
    public class PizzaDbContext : IdentityDbContext<APIUser>
    {
        public PizzaDbContext(DbContextOptions<PizzaDbContext> options) : base(options)
        {

        }
        public DbSet<Pizza> Pizzas { get; set; }
      /*  public DbSet<Order> Orders { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Category> Categories { get; set; }*/

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            base.OnModelCreating(modelBuilder);
            /*modelBuilder.Entity<Pizza>()
            .HasOne(p => p.Category)
            .WithMany(c => c.Pizzas)
            .HasForeignKey(p => p.CategoryId)
            .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Cart>()
                .HasOne(c => c.Pizza)
                .WithMany()
                .HasForeignKey(c => c.PizzaId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Cart>()
                .HasOne(c => c.Order)
                .WithMany(o => o.Pizzas)
                .HasForeignKey(c => c.OrderId)
                .OnDelete(DeleteBehavior.Cascade);*/
            modelBuilder.ApplyConfiguration(new RoleConfiguration());
            modelBuilder.Entity<Pizza>().HasData(
                new Pizza {
                    PizzaId = 01,
                    Name = "Capricano", 
                    Price = 500,
                    Description ="Random Values",
                   // CategoryId =01 
                   },
                new Pizza {
                    PizzaId = 02,
                    Name = "Kabab Pizza",
                    Price = 700,
                    Description = "Random Values",
                    //CategoryId = 02
                });
          /*  modelBuilder.Entity<Order>().HasData(
                new Order { }
                );
            modelBuilder.Entity<Cart>().HasData(
                new Cart
                {
                    CartId = 0,
                    Quantity = 0,
                    TotalPrice = 0.0

                });
            modelBuilder.Entity<Category>().HasData(
                new Category 
                {
                    CategoryId =01,
                    Name ="Veg",
                    
      
                },
                new Category 
                {
                    CategoryId =02,
                    Name = "Non_Veg",
                    
                });*/
        }


    }
}
