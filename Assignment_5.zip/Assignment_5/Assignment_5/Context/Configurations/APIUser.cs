﻿using Microsoft.AspNetCore.Identity;

namespace Assignment_5.Context.Configurations
{
    public class APIUser: IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
