﻿using AutoMapper;
using Assignment_4.Context;


using Assignment_4.Models.Pizza;


namespace PizzaWebProjectAPI.Configuration
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<Pizza,CreatePizzaDto>().ReverseMap();
            CreateMap<Pizza,GetAllPizzaDto>().ReverseMap();
            CreateMap<Pizza,GetAPizzaDto>().ReverseMap();
            
        }
    }
}
