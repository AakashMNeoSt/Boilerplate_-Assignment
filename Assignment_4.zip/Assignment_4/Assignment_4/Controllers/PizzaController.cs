﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Assignment_4.Context;
using Assignment_4.Models.Pizza;
using Assignment_4.Repository;
using System.Diagnostics.Metrics;

namespace Assignment_5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PizzaController : ControllerBase
    {
        readonly IPizzaRepository _pizzaRepository;
        readonly IMapper _mapper;
        public PizzaController(IPizzaRepository pizzaRepository, IMapper mapper)
        {
            _pizzaRepository = pizzaRepository;
            _mapper = mapper;
        }

        /*
          [HttpGet]
        [Authorize]
        
        public async Task<ActionResult> GetCountries()
        {
            List<Country> allCountries = await _countryRepository.GetAllCountries();
            var records = _mapper.Map<List<GetAllCountryDto>>(allCountries);
            return Ok(records);
        }
         */


        [HttpGet]
        //[Authorize]
        public async Task<ActionResult> GetPizzas()
        {
            List<Pizza> allPizza = await _pizzaRepository.GetAllPizza();
            var records = _mapper.Map<List<GetAllPizzaDto>>(allPizza);
            return Ok(records);
        }


        /*[HttpGet("{id}")]
        public async Task<ActionResult<GetCountryDetailsDto>> GetCountry(int id)
        {
            Country country = await _countryRepository.GetCountryById(id);
            //if (country == null)
            //{
            //    return NotFound();
            //}
            var countryDto = _mapper.Map<GetCountryDetailsDto>(country);
            return Ok(countryDto);

        }*/
        [HttpGet("{id}")]
        public async Task<ActionResult<GetAPizzaDto>> GetPizza(int id)
        {
            Pizza pizza =await _pizzaRepository.GetPizzaById(id);
            if (pizza == null)
            {
                return NotFound(" not found");
                //return NotFound($" not found");
            }
            var pizzaDto = _mapper.Map<GetAPizzaDto>(pizza);
            return Ok(pizzaDto);
        }

        [HttpPost]
        public async Task<ActionResult> CreatePizza(CreatePizzaDto createPizzaDto)
        {

            var pizza = _mapper.Map<Pizza>(createPizzaDto);
            _pizzaRepository.AddPizza(pizza);
            return CreatedAtAction("GetPizza",new { id = pizza.PizzaId }, pizza);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePizza(int id, UpdatePizzaDto updatePizzaDto)
        {
            var existingPizza = await _pizzaRepository.GetPizzaById(id);
            if (existingPizza == null)
            {
                return NotFound();
            }

            existingPizza.Name = updatePizzaDto.Name;
            existingPizza.Price = updatePizzaDto.Price;
            existingPizza.Description = updatePizzaDto.Description;

            await _pizzaRepository.UpdatePizza(existingPizza);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePizza(int id)
        {
            var existingPizza = await _pizzaRepository.GetPizzaById(id);
            if (existingPizza == null)
            {
                return NotFound();
            }

            await _pizzaRepository.DeletePizza(id);

            return NoContent();
        }


    }
}