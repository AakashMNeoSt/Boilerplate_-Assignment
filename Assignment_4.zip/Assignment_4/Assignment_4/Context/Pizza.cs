﻿using System.ComponentModel.DataAnnotations;

namespace Assignment_4.Context
{
    public class Pizza
    {
        [Key]
        public int PizzaId { get; set; }
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string? Description { get; set; }

        // Navigation properties
       /* public int CategoryId { get; set; }
        public Category? Category { get; set; }
       */


    }



}
