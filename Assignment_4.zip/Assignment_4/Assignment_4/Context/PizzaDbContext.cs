﻿using Assignment_4.Context;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


using System.Diagnostics.Metrics;

namespace Assignment_4.Context
{
    public class PizzaDbContext : IdentityDbContext
    {
        public PizzaDbContext(DbContextOptions<PizzaDbContext> options) : base(options)
        {

        }
        public DbSet<Pizza> Pizzas { get; set; }
      /*  public DbSet<Order> Orders { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Category> Categories { get; set; }*/

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            base.OnModelCreating(modelBuilder);
          
           // modelBuilder.ApplyConfiguration(new RoleConfiguration());
            modelBuilder.Entity<Pizza>().HasData(
                new Pizza {
                    PizzaId = 01,
                    Name = "Capricano", 
                    Price = 500,
                    Description ="Random Values",
                 
                   },
                new Pizza {
                    PizzaId = 02,
                    Name = "Kabab Pizza",
                    Price = 700,
                    Description = "Random Values",
                   
                });
        }


    }
}
