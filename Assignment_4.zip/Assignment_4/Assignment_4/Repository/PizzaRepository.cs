﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Assignment_4.Context;

namespace Assignment_4.Repository
{
    public class PizzaRepository : IPizzaRepository
    {
        readonly PizzaDbContext _context;
        public PizzaRepository(PizzaDbContext pizzaDbContext)
        {
            _context = pizzaDbContext;
        }

        public void AddPizza(Pizza pizza)
        {
            _context.Pizzas.Add(pizza);
            _context.SaveChanges();
        }

        /*
          public async Task<List<Country>> GetAllCountries()
        {
            return await _context.Countries.ToListAsync();
        }
         */
        public async Task<List<Pizza>> GetAllPizza()
        {
            return await _context.Pizzas.ToListAsync();
        }

       /* public async Task<Order> GetOrder(Order order)
        {
            return await _context.Orders.ToListAsync();
        }
*/
        public async Task<Pizza> GetPizzaById(int id)
        {
            return await _context.Pizzas.FirstOrDefaultAsync(a => a.PizzaId == id);
        }

        /*
          public void UpdateCourse (Course course)
        {
            var existingCourse = _context.Courses.FirstOrDefault(q => q.Id == course.Id);
            if (existingCourse != null)
            {
                existingCourse.Name = course.Name;
                existingCourse.Price = course.Price;
                existingCourse.Description = course.Description;

            }
        }
        */
       
        public async Task UpdatePizza(Pizza pizza)
        {
            var existingPizza = await _context.Pizzas.FindAsync(pizza.PizzaId);
            if (existingPizza != null)
            {
                existingPizza.Name = pizza.Name;
                existingPizza.Price = pizza.Price;
                existingPizza.Description = pizza.Description;

                await _context.SaveChangesAsync();
            }
        }

        /*
        public void DeleteCourse(int id)
        {
            var existingCourse = _context.Courses.FirstOrDefault(a=> a.Id == id);
            if(existingCourse != null)
            {
                _context.Courses.Remove(existingCourse);
            }
         */
      
        public async Task DeletePizza(int id)
        {
            var existingPizza = await _context.Pizzas.FindAsync(id);
            if (existingPizza != null)
            {
                _context.Pizzas.Remove(existingPizza);
                await _context.SaveChangesAsync();
            }
        }
    }
}
