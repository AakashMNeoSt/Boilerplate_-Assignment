﻿using Assignment_4.Context;

namespace Assignment_4.Repository
{
    public interface IPizzaRepository
    {
        void AddPizza(Pizza pizza);
        Task<List<Pizza>> GetAllPizza();
        Task<Pizza> GetPizzaById(int id);
        Task DeletePizza(int id);
        Task UpdatePizza(Pizza pizza);

        /*Task<Order>GetOrder(Order order);*/

    }
}
