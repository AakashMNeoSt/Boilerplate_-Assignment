using Assignment_4._1.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Serilog;

namespace Assignment_4._1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            var logger = new LoggerConfiguration()
                .ReadFrom.Configuration(builder.Configuration)
                .CreateLogger();
            builder.Logging.ClearProviders();
            builder.Logging.AddSerilog(logger);

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(c =>c.ResolveConflictingActions(x =>x.Last()));

            builder.Services.AddApiVersioning(setup => {
                setup.DefaultApiVersion = new ApiVersion(1, 0);
                setup.AssumeDefaultVersionWhenUnspecified =true;
                setup.ReportApiVersions =true;
                setup.ApiVersionReader = new HeaderApiVersionReader("X-Version");

                var conv = setup.Conventions.Controller<WeatherForecastController>();
                conv.HasApiVersion(new ApiVersion(1,0));
                conv.HasApiVersion(new ApiVersion(1,1));
                conv.HasDeprecatedApiVersion(new ApiVersion(1,0));
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}