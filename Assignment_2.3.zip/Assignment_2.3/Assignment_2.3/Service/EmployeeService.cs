﻿using Assignment_2._3.Interface;
using AutoMapper;
using DataLayer;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

namespace Assignment_2._3.Service
{
    public class EmployeeService : IEmployee
    {
        private readonly DataContext dataContext;
        private readonly IMapper mapper;

        public EmployeeService(DataContext _dataContext, IMapper _mapper)
        {
            this.dataContext = _dataContext;
            this.mapper = _mapper;
        }

        public void CreateEmployee(AddEmployee addEmployee)
        {
            var employee = mapper.Map<Employee>(addEmployee);
            dataContext.Employees.Add(employee);
            dataContext.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            var employee = dataContext.Employees.Find(id);
            if (employee != null)
            {
                dataContext.Employees.Remove(employee);
                dataContext.SaveChanges();
            }
        }

        public IEnumerable<Employee> GetAllEmployee()
        {
            var employee = dataContext.Employees.ToList();
            return mapper.Map<List<Employee>>(employee);
        }

        public void UpdateEmployee(UpdateEmployee updateEmployee)
        {
            var employee = dataContext.Employees.Find(updateEmployee.Id);
            if (employee != null)
            {
                employee.Id = updateEmployee.Id;
                employee.Name = updateEmployee.Name;
                dataContext.SaveChanges();
            }
        }
    }
}
