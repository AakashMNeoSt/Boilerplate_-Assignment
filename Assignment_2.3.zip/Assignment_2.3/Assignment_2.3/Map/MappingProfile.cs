﻿using AutoMapper;
using DataLayer;
using Microsoft.Extensions.Hosting;

namespace Assignment_2._3.Map
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Employee, AddEmployee>().ReverseMap();
            CreateMap<Employee, UpdateEmployee>().ReverseMap();
        }
    }
}
