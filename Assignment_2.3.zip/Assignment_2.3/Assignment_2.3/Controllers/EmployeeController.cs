﻿using Assignment_2._3.Interface;
using DataLayer;
using Microsoft.AspNetCore.Mvc;

namespace Assignment_2._3.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployee employee;

        public EmployeeController(IEmployee employee)
        {
            this.employee = employee;
        }

        public IActionResult Index()
        {
            var emp = employee.GetAllEmployee();
            return View(emp);
        }
        [HttpPost]
        public IActionResult Create(AddEmployee addEmployee)
        {
            if (ModelState.IsValid)
            {
                employee.CreateEmployee(addEmployee);
                return RedirectToAction("Index");
            }

            return View(addEmployee);
        }

        [HttpPost]
        public IActionResult Edit(UpdateEmployee updateEmployee)
        {
            if (ModelState.IsValid)
            {
                employee.UpdateEmployee(updateEmployee);
                return RedirectToAction("Index");
            }

            return View(updateEmployee);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            employee.DeleteEmployee(id);
            return RedirectToAction("Index");
        }
    }
}
