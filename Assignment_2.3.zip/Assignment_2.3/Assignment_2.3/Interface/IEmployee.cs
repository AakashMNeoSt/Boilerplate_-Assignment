﻿using DataLayer;

namespace Assignment_2._3.Interface
{
    public interface IEmployee
    {
        IEnumerable<Employee> GetAllEmployee();
        void CreateEmployee(AddEmployee addEmployee);
        void UpdateEmployee(UpdateEmployee updateEmployee);
        void DeleteEmployee(int id);
    }
}
